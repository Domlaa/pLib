package com.smart.ppx;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.View;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.smart.ppx.bean.PPX;
import com.smart.ppx.bean.Result;
import com.smart.ppx.download.DownloadListener;
import com.smart.ppx.download.FileUtil;
import com.smart.ppx.net.HttpClient;
import com.smart.ppx.net.IClient;
import com.smart.ppx.okhttp.HttpManager;
import com.smart.ppx.okhttp.IResponseListener;
import com.smart.ppx.picture.ImageActivity;

import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import static com.smart.ppx.Config.*;


public class MainActivity extends BaseActivity {

    private String prefix;
    ClipboardManager clipboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
    }

    private boolean linkLegal(String url) {
        return url.contains(PREFIX) && url.length() == 31;
    }

    private String pasteLegal() {
        String pasteString = clipboard.getText().toString();
        if (linkLegal(pasteString)) {
            return pasteString;
        } else {
            toast("请在粘贴板复制正确链接,当前粘贴板内容：" + pasteString + ",长度：" + pasteString.length());
        }
        return null;
    }

    /**
     * 1.获取粘贴板，检测合理
     * 2.根据分享连接获取id
     * 3.直接打开
     */
    public void open(View view) {
        String pasteString = pasteLegal();
        if (pasteString != null) {
            try {
                getId(pasteString, this::openPPX);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressLint("StaticFieldLeak")
    private static void getId(String path, HttpClient.Callback callback) {
        new AsyncTask<Void, Void, Exception>() {
            String result;

            @Override
            protected Exception doInBackground(Void... params) {
                try {
                    HttpURLConnection conn = (HttpURLConnection) new URL(path)
                            .openConnection();
                    conn.setInstanceFollowRedirects(false);
                    conn.setConnectTimeout(5000);
                    String url = conn.getHeaderField("Location");
                    result = url.substring(26, url.indexOf("?"));
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Exception exception) {
                super.onPostExecute(exception);
                callback.complete(result);
            }
        }.execute();
    }


    public void down(View view) {
        String url = pasteLegal();
        if (url == null) {
            return;
        }
        prefix = url.substring(23, 29);
        if (FileUtil.videoExist(prefix)) {
            toast("文件已存在！");
            return;
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN) {
            String[] permissions = new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE};
            requestPermissions("请授予以下权限", permissions, callback);
        }
    }


    private void openPPX(String id) {
        Log.i(TAG, "openPPX: " + id);
        //com.sup.android.detail.ui.DetailActivity
        // bds://cell_detail?item_id=6800586962215377163
        Intent intent = new Intent("android.intent.action.VIEW",
                android.net.Uri.parse("bds://cell_detail?item_id=" + id));
        intent.setPackage(Config.PACKAGE);
        startActivity(intent);
    }

    /**
     * 获取PPX播放信息
     *
     * @param postfix 短链后缀
     */
    public void getPlaySource(String postfix) {
        HttpManager.getInstance().get(SERVER + postfix,
                new IResponseListener() {
                    @Override
                    public void onSuccessful(Result data) {
                        PPX ppx = JSONObject.parseObject(data.getData(), PPX.class);
                        downVideo(ppx.getUrl());
                    }

                    @Override
                    public void onFailure(int errorCode, String errorMsg) {
                        toast("访问错误" + errorMsg);
                    }

                    @Override
                    public void finished() {
                    }
                });
    }

    private PermissionCallback callback = new PermissionCallback() {
        @Override
        public void hasPermission() {
            String url = pasteLegal();
            if (url != null) {
                getPlaySource(url.substring(23, 30));
            }
        }

        @Override
        public void noPermission() {
            toast("下载失败，请授予存储权限");
        }
    };

    private void downVideo(String url) {
        //实例化进度条对话框（ProgressDialog）
        final ProgressDialog pd = new ProgressDialog(this);
        //设置对话进度条样式为水平
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        //设置提示信息
        pd.setMessage("正在下载....");
        //设置对话进度条显示在屏幕顶部（方便截图）
        pd.getWindow().setGravity(Gravity.CENTER);
        pd.setMax(100);
        FileUtil.download(prefix, url, new DownloadListener() {
            @Override
            public void start(long max) {
                runOnUiThread(() -> {
                    pd.show();
                    toastOnUI("开始下载。。。");
                });
            }

            @Override
            public void loading(int progress) {
                runOnUiThread(() -> pd.setProgress(progress));
            }

            @Override
            public void complete(String path) {
                runOnUiThread(() -> {
                    pd.dismiss();
                    toastOnUI(path + "已下载到PPX目录下");
                });
                updateAlbum(path);
            }

            @Override
            public void fail(int code, String message) {
                runOnUiThread(() -> {
                    pd.dismiss();
                    toastOnUI("下载失败" + message);
                });
            }

            @Override
            public void loadFail(String message) {
                runOnUiThread(() -> {
                    pd.dismiss();
                    toastOnUI("下载失败" + message);
                });
            }
        });
    }

    private void updateAlbum(String fileName) {
        MediaScannerConnection.scanFile(this, new String[]{fileName},
                new String[]{"video/mp4"}, (path1, uri) -> System.out.println(path1));
    }


    public void link(View view) {
        String pasteString = pasteLegal();
        if (pasteString != null) {
            String url = PLAY + pasteString.substring(23, 30);
            shorter(url, url1 -> {
                clipboard.setText(url1);
                toast(url1);
            });
        }
    }


    @SuppressLint("StaticFieldLeak")
    public static void shorter(String url, HttpClient.Callback callback) {
        new AsyncTask<Void, Void, Exception>() {
            String result;

            @Override
            protected Exception doInBackground(Void... params) {
                try {
                    String formatUrl = URLEncoder.encode(url, "UTF-8");
                    IClient client = new HttpClient(SHORT);
                    client.addParam("url", formatUrl);
                    client.addParam("key", KEY);
                    result = client.get();
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Exception exception) {
                super.onPostExecute(exception);
                System.out.println("result::" + result);
                callback.complete(result);
            }
        }.execute();
    }

    public void pic(View view) {
        String pasteString = pasteLegal();
        if (pasteString != null) {
            try {
                image(pasteString.substring(23, 30));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void image(String postfix) {
        HttpManager.getInstance().get(IMAGE + postfix,
                new IResponseListener() {
                    @Override
                    public void onSuccessful(Result data) {
                        JSONArray list = JSONArray.parseArray(data.getData());
                        if (list != null && list.size() > 0) {
                            ArrayList<String> images = new ArrayList<>();
                            for (int a = 0; a < list.size(); a++) {
                                images.add(list.getString(a));
                            }
                            ImageActivity.start(MainActivity.this, postfix, images);
                        } else {
                            toast(data.getMsg());
                        }
                    }

                    @Override
                    public void onFailure(int errorCode, String errorMsg) {
                        toast("访问错误" + errorMsg);
                    }

                    @Override
                    public void finished() {
                    }
                });
    }


}
