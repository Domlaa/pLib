package com.smart.ppx;

public class Config {

    public static final String HOST = "rezz.top";
    //public static final String HOST = "192.168.43.231";

    //public static final String HOST = "47.95.142.57";

//    public static final String SERVER = "http://"+HOST+":8080/chat/bd?postfix=";
//    public static final String IMAGE = "http://"+HOST+":8080/chat/img?postfix=";
//    public static final String PLAY = "http://"+HOST+":8080/chat/play?postfix=";

    public static final String SERVER = "http://"+HOST+":80/bd?postfix=";
    public static final String IMAGE = "http://"+HOST+":80/img?postfix=";
    public static final String PLAY = "http://"+HOST+":80/play?postfix=";

    public static final String SHORT = "http://suo.nz/api.php";
    public static final String KEY = "5e669b9b44bb357519e2ff0c@e0ea2bb377708b3344dd4a57193de9e5";

    public static final String PACKAGE = "com.sup.android.superb";

    public static final String TAG = "MainActivity";
    public static final String ID = "6800586962215377163";

    public static final String PREFIX = "https://h5.pipix.com/s/";
    public static final String POSTFIX = "nAKbEs/";

}
